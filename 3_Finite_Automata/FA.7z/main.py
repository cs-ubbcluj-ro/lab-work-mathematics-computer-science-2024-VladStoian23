def read_fa_from_file(filename):

    with open(filename, 'r') as file:
        lines = [line.strip() for line in file.readlines()]


    states_line = lines[0]
    if states_line.startswith("States:"):
        states = set(states_line.split(":")[1].split(","))
    else:
        raise ValueError("Missing or invalid 'States:' line.")

    alphabet_line = lines[1]
    if alphabet_line.startswith("Alphabet:"):
        alphabet = set(alphabet_line.split(":")[1].split(","))
    else:
        raise ValueError("Missing or invalid 'Alphabet:' line.")

    start_state_line = lines[2]
    if start_state_line.startswith("Start State:"):
        start_state = start_state_line.split(":")[1].strip()
    else:
        raise ValueError("Missing or invalid 'Start State:' line.")

    transitions = {}
    in_transitions = False
    for line in lines[3:]:
        if line.startswith("Transitions:"):
            in_transitions = True
            continue
        if line.startswith("Accepting States:"):
            accepting_states_line = line
            break
        if in_transitions and "->" in line:
            parts = line.split("->")
            left = parts[0].strip().split(",")
            right = parts[1].strip()
            key = (left[0], left[1])
            transitions[key] = right


    if accepting_states_line.startswith("Accepting States:"):
        accepting_states_raw = accepting_states_line.split(":")[1].strip().split(",")
        accepting_states = {}
        for item in accepting_states_raw:
            state, token_type = item.strip().split("(")
            token_type = token_type.strip(")")
            accepting_states[state.strip()] = token_type.strip()
    else:
        raise ValueError("Missing or invalid 'Accepting States:' line.")

    return states, alphabet, start_state, transitions, accepting_states


def display_fa(states, alphabet, start_state, transitions, final_states):

    print("Set of States:", states)
    print("Alphabet:", alphabet)
    print("Start State:", start_state)
    print("Transitions:")
    for (state, symbol), result in transitions.items():
        print(f"  δ({state}, {symbol}) -> {result}")
    print("Set of Final States:", final_states)


# Main Execution
if __name__ == "__main__":
    filename = "FA.in"
    states, alphabet, start_state, transitions, final_states = read_fa_from_file(filename)
    display_fa(states, alphabet, start_state, transitions, final_states)
